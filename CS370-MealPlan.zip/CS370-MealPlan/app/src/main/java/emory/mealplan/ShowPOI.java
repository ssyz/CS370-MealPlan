package emory.mealplan;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ShowPOI extends AppCompatActivity {

    //@Override
    //protected void onCreate(Bundle savedInstanceState) {
       // super.onCreate(savedInstanceState);
     //   setContentView(R.layout.activity_show_poi);
   // }
}
