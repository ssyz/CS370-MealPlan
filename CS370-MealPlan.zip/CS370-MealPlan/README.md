# CS370-MealPlan
Android Application for Emory students seeking an innovative approach towards a better end-to-end dining experience.
